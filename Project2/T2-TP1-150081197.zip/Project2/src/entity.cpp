#include "entity.h"

entity::entity()
{
    //ctor
}

entity::~entity()
{
    //dtor
}
