#ifndef ENTITY_H
#define ENTITY_H


class entity
{
    public:
        entity();
        virtual ~entity();

    protected:

    private:
};

#endif // ENTITY_H
