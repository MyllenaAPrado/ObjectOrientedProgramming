var searchData=
[
  ['name_14',['Name',['../class_name.html',1,'']]],
  ['number_15',['Number',['../class_number.html',1,'']]]
];
