var searchData=
[
  ['name_74',['Name',['../class_name.html',1,'']]],
  ['number_75',['Number',['../class_number.html',1,'']]]
];
