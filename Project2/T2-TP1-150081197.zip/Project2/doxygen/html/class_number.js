var class_number =
[
    [ "getNumber", "class_number.html#abb85fa0617d118a3c56ce5c9a669d8f9", null ],
    [ "setNumber", "class_number.html#a360259127fb51cd44be66b20862d8616", null ]
];