var files_dup =
[
    [ "domains.h", "domains_8h_source.html", null ],
    [ "domainsTests.h", "domains_tests_8h_source.html", null ],
    [ "entities.h", "entities_8h_source.html", null ],
    [ "entitiesTests.h", "entities_tests_8h_source.html", null ]
];