var class_address =
[
    [ "getAddress", "class_address.html#af5688a2adfe179749c672eebf8ef7182", null ],
    [ "setAddress", "class_address.html#abc7828a9c42ad2be332c910387f97b8d", null ]
];