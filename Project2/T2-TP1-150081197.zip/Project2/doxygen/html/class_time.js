var class_time =
[
    [ "getHour", "class_time.html#aacb846812dccbf244d52e0f237ad0026", null ],
    [ "getMinutes", "class_time.html#a06d35e6dcd19e0a1d335d24c24fe624c", null ],
    [ "getTime", "class_time.html#a9a5aa647045a9cb6100b0ea2beb5a371", null ],
    [ "setTime", "class_time.html#abc23086fdf930c14d235c67b9a5e1867", null ]
];