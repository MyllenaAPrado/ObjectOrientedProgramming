var class_term =
[
    [ "getTerm", "class_term.html#a14231ea75496562e9fc924b721c079e2", null ],
    [ "setTerm", "class_term.html#a471675e6f9d3cdf128f834a5226b348d", null ]
];