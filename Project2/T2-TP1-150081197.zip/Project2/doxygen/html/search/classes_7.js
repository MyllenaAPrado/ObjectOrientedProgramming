var searchData=
[
  ['name_72',['Name',['../class_name.html',1,'']]],
  ['number_73',['Number',['../class_number.html',1,'']]]
];
