var searchData=
[
  ['name_13',['Name',['../class_name.html',1,'']]],
  ['number_14',['Number',['../class_number.html',1,'']]]
];
