var class_name =
[
    [ "getName", "class_name.html#a7f4a8733ea0217e233182259d6ddc870", null ],
    [ "setName", "class_name.html#aa1e0ac7e01a41b7e8589d295925903c3", null ]
];