var class_emitter =
[
    [ "getEmitter", "class_emitter.html#a742421946827c427088a87dabb05da23", null ],
    [ "setEmitter", "class_emitter.html#a34fcbb486ca483feeba0db42bffa7ee8", null ]
];