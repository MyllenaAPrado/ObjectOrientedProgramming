var class_fee =
[
    [ "getFee", "class_fee.html#ae2067afc68c028cdcd0c6cdea32a4455", null ],
    [ "setFee", "class_fee.html#a7c0c26347944e59c57b90bda1987983b", null ]
];