var class_aplication_code =
[
    [ "getCode", "class_aplication_code.html#a9bed115f6df6fb2a3b46f8c3b123cf43", null ],
    [ "setCode", "class_aplication_code.html#a0c1304c2c5f5330d55ff0d0044b178dc", null ]
];