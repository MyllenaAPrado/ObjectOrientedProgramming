var class_cpf =
[
    [ "getCpf", "class_cpf.html#a653a6fc70f3281104a15b0891cd5acdf", null ],
    [ "setCpf", "class_cpf.html#aec03428cfc5f00210ee6442d83d36528", null ]
];