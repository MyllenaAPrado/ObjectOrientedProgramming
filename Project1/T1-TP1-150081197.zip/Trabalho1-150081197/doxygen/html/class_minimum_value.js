var class_minimum_value =
[
    [ "getMinimumValue", "class_minimum_value.html#a5bd06813feb6c008c7fce4c7a2d4ea9e", null ],
    [ "setMinimumValue", "class_minimum_value.html#ab0e620b05f4490d45e3b93dcf7934d2a", null ]
];