var class_aplication_value =
[
    [ "getAplicationValue", "class_aplication_value.html#a7ec83814cd6aa61d137cd6bf2f1660a1", null ],
    [ "setAplicationValue", "class_aplication_value.html#a1a3424cb9ac34ab5ecab8ed057ec073a", null ]
];