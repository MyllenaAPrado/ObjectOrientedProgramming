var class_clazz =
[
    [ "getClazz", "class_clazz.html#ae4cde750705e4acfe997c23df3ed5b31", null ],
    [ "setClazz", "class_clazz.html#ad9910230b1b795ce0bd990a3334cf7b6", null ]
];