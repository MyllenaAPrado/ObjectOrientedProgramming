var searchData=
[
  ['name_62',['Name',['../class_name.html',1,'']]],
  ['number_63',['Number',['../class_number.html',1,'']]]
];
