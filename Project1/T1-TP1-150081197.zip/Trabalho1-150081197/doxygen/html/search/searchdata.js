var indexSectionsWithContent =
{
  0: "abcdefmnpstz",
  1: "abcdefmnptz",
  2: "s"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

