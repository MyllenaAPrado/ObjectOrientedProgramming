# Trabalho 1 - 15/0081197
  Projeto feito por : Myllena de Almeida Prado - 150081197

# Ambiente de desenvolvimento do projeto
  1. Codeblocks [versão 20.03](http://www.codeblocks.org/downloads/26)
  2. Windows 10.

# Requisitos para rodar o programa
 1. Compilador GCC++.
 2. CodeBlocks pode ser usado para execução do programa.

# Convenção de codificação
  1. Os nomes das classes e variáveis foram escritas em inglês.
  2. Para a classe adotou-se a convenção de início de nome com letra maiúscula e se for composta por duas palavras a segunda palavra também começa com letra maiúscula. 
  Ex: PrimeiroSegundo.
  3. Para os atributos a letra de início da variável é minuscula e caso seja formada por duas palavra a segunda palavra começa com letra maiúscula. 
  Ex: primeiroSegundo.
  4. A documentação das classes e dos métodos foi feita em português.
  5. Na main é impresso na tela o nome da classe testada e o resultado do teste na freste. Ex: Classe: SUCESS.
  
# Execução do projeto
  No diretório principal do projeto contém o arquivo "Trabalho1-150081197.cpp", com esse arquivo é possível executar o programa tanto pelo codeblocks quanto pelo terminal.
